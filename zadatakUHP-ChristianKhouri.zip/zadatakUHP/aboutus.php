<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>About us</title>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
</head>
<body>

<h1>About Us</h1>

<h1>Pages</h1>
<ul>
<li>
	<a href="home.php">Home</a>
</li>
<li>
	<a href="aboutus.php">About us</a>
</li>

<li>
	<a href="admin/index.php">ADMIN</a>
</li>
</ul>
  
 
</script>
</body>
</html>

<script>
$(document).ready(function(){
	var pageName = document.location.pathname.match(/[^\/]+$/)[0];	
	if(pageName == "aboutus.php"){
		pageName = "AboutUs";
	}
    $.ajax({
        type: "GET",
        url: "includes/insert.php",
		data: {'pageName':pageName}
    });
});
</script>
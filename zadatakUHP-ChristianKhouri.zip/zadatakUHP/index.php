 
<!DOCTYPE html>
<html>
<head>
<title>HomePage</title>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
</head>
<body>

<h1>Pages</h1>
<ul>
<li>
	<a href="home.php">Home</a>
</li>
<li>
	<a href="aboutus.php">About us</a>
</li>
</ul>
 
</script>
</body>
</html>
 
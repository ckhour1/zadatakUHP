<?php
include_once 'db_connect.php';
include_once 'functions.php';

$user_os         = getOS();
$user_browser    = getBrowser();
$user_ip_address = getIpAddress();
$page_name       = $_GET['pageName'];

$curr_time      =  date("H:i");

$count_page_viewed = 1;

$result = $db->query("SELECT * FROM visitors_detalis WHERE visitor_ip_address = '".$user_ip_address."'
                                                       AND page_name          = '".$page_name."' ");
 
if($result['count'] > 0){

	foreach($result['rows'] as $row){
		$count_page_viewed = $row['visitor_page_viewed'] + 1;
	}

	$return = $db->update("UPDATE visitors_detalis SET visitor_page_viewed  = '.$count_page_viewed.', visitor_time = '.$curr_time.'
												 WHERE visitor_ip_address  = '".$user_ip_address."'
												   AND page_name           = '".$page_name."' ");	

}else{
	$result = $db->query("INSERT INTO visitors_detalis(visitor_ip_address, visitor_page_viewed, visitor_time, visitor_browser, visitor_os, page_name) 
                                                VALUES('$user_ip_address', '.$count_page_viewed.', '.$curr_time.', '$user_browser', '$user_os', '$page_name')");
}	 



					  
?>					 
 <?php
 include_once 'class.php';
 
 $db = new Database("localhost", "root", "", "zadatakuhp");
 ?>
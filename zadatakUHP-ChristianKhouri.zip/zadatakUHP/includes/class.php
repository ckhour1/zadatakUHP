<?php
class Database {

    private	$mysqli;
    private $host, $username, $password, $database;

    public function __construct($host, $username, $password, $database){
        $this->host        = $host;
        $this->username    = $username;
        $this->password    = $password;
        $this->database    = $database;

        $this->mysqli = new mysqli($this->host, $this->username, $this->password)
            OR die("There was a problem connecting to the database.");

        /* check connection */
        if (mysqli_connect_errno()) {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }

        $this->mysqli->select_db($this->database);

        if (mysqli_connect_errno()) {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }

        return true;
    }

    public function query($query) {

        $return = array();

        if(!$result = $this->mysqli->query($query))
        {
            $return['success'] = false;
            $return['error'] = $this->mysqli->error;

            return $return;
        }

        $return['success'] = true;
        $return['affected_rows'] = $this->mysqli->affected_rows;
        $return['insert_id'] = $this->mysqli->insert_id;

        if(0 == $this->mysqli->insert_id)
        {
            $return['count'] = $result->num_rows;
            $return['rows'] = array();

            while ($row = $result->fetch_assoc()) {
                $return['rows'][] = $row;
            }

            $result->close();
        }

        return $return;
    }
	
	public function update($query) {
		$return = array();
        $result = $this->mysqli->query($query);
        return $return;
    }
 

    public function __destruct() {
        $this->mysqli->close()
            OR die("There was a problem disconnecting from the database.");
    }
	
}
?>
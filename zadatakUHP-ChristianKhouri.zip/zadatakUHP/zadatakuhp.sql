-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2019 at 06:28 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zadatakuhp`
--

-- --------------------------------------------------------

--
-- Table structure for table `visitors_detalis`
--

CREATE TABLE `visitors_detalis` (
  `visitor_id` int(11) UNSIGNED NOT NULL,
  `visitor_ip_address` varchar(15) NOT NULL,
  `visitor_page_viewed` int(6) NOT NULL,
  `visitor_time` char(255) NOT NULL,
  `visitor_browser` varchar(255) NOT NULL,
  `visitor_os` varchar(255) NOT NULL,
  `page_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitors_detalis`
--

INSERT INTO `visitors_detalis` (`visitor_id`, `visitor_ip_address`, `visitor_page_viewed`, `visitor_time`, `visitor_browser`, `visitor_os`, `page_name`) VALUES
(191, '::1', 3, '.18:26.', 'Chrome', 'Windows 10', 'HomePage'),
(192, '::1', 4, '.18:26.', 'Chrome', 'Windows 10', ''),
(193, '::1', 1, '.18:24.', 'Chrome', 'Windows 10', 'AboutUs');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `visitors_detalis`
--
ALTER TABLE `visitors_detalis`
  ADD PRIMARY KEY (`visitor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `visitors_detalis`
--
ALTER TABLE `visitors_detalis`
  MODIFY `visitor_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=194;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
